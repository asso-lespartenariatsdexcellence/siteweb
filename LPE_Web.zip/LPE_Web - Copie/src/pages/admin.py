from django.contrib import admin
from .models import Cours
# Register your models here.

admin.site.register(Cours)
